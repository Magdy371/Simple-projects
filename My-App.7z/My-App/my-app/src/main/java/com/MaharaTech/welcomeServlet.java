package com.MaharaTech;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class welcomeServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        @SuppressWarnings("unused")
        String password = req.getParameter("password");
        PrintWriter out  = resp.getWriter();
        out.print("<h4>" + "Hello " + email + "<h4>");
    }
    
}
