package com.MaharaTech;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class checkFormServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        if(email !=null && !email.isEmpty() && password !=null && !password.isEmpty())
        {
            RequestDispatcher rd  = req.getRequestDispatcher("welcomePage");
            rd.forward(req, resp);
        }else{
            resp.setContentType("text/html");
            RequestDispatcher rd = req.getRequestDispatcher("login.html");
            resp.getWriter().print("all fields are required");
            rd.include(req, resp);
        }
    }
}
