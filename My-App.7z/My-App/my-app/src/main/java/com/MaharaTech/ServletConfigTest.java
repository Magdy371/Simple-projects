package com.MaharaTech;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
public class ServletConfigTest implements Servlet{

    private ServletConfig myConfig;
    @Override
    public void init(ServletConfig config) throws ServletException {
        this.myConfig = config;
        System.out.println("Servlet is initialized");
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.myConfig;
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<h4>" + "The Servlet Configuration Test parameter is"+"<h4>");
        out.println("<p>" + getServletConfig().getInitParameter("Country") + "</p>");
    }

    @Override
    public String getServletInfo() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void destroy() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
