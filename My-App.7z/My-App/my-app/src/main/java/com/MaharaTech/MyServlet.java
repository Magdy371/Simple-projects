package com.MaharaTech;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class MyServlet implements Servlet {
    private ServletConfig config;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
        System.out.println("Servlet is initialized");
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        String name = config.getInitParameter("Age");
        PrintWriter out = res.getWriter();
        out.println("<h1>Servlet is serviced<h1>");
        out.println("<h1>My Age is: " + name + "<h1>");
    }

    @Override
    public void destroy() {
        System.out.println("Servlet is destroyed");
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }

    @Override
    public String getServletInfo() {
        return "MyServlet Information";
    }
}